const { Client, GatewayIntentBits } = require('discord.js');
const fs = require('fs');

// Bot token'ınızı buraya ekleyin
const token = 'MTI2NTk5NjUxMDEzOTc3NzEyNw.GTcZpu.bYTEig2SuZm3kBbq-yLZqoSoqoDu3xNLr5Pwlc';

const client = new Client({ intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent] });

let mesaiData = {};

// Veriyi yüklerken her kullanıcı için bir dizi olup olmadığını kontrol edin
if (fs.existsSync('mesaiData.json')) {
    mesaiData = JSON.parse(fs.readFileSync('mesaiData.json'));
    for (let userId in mesaiData) {
        if (!Array.isArray(mesaiData[userId])) {
            mesaiData[userId] = [];
        }
    }
} else {
    fs.writeFileSync('mesaiData.json', JSON.stringify(mesaiData));
}

const saveData = () => {
    fs.writeFileSync('mesaiData.json', JSON.stringify(mesaiData, null, 2));
};

client.once('ready', () => {
    console.log('Ready!');
    updateActivity();
    setInterval(updateActivity, 30000); // 30 saniye aralıklarla güncelle
});

const updateActivity = () => {
    const activeUsers = Object.keys(mesaiData).filter(userId => mesaiData[userId].some(mesai => mesai.end === null)).length;
    client.user.setActivity(`${activeUsers} aktif memur`, { type: 'PLAYING' });
    console.log('Activity updated'); // Aktivite güncellendiğinde konsola yazdır
};

client.on('messageCreate', message => {
    if (message.content === '!mesaigir') {
        handleMesaigir(message);
    } else if (message.content === '!mesaiçık') {
        handleMesaiCik(message);
    } else if (message.content === '!mesaibilgi') {
        handleMesaibilgi(message);
    } else if (message.content === '!aktif') {
        handleAktif(message);
    } else if (message.content === '!toplist') {
        handleToplist(message);
    } else if (message.content.startsWith('!mesaiçıkar')) {
        handleMesaiCikar(message);
    } else if (message.content === '!mesailerisıfırla') {
        handleMesaiLerisifirla(message);
    } else if (message.content.startsWith('!mesaisil')) {
        handleMesaiSil(message);
    } else if (message.content === '!tümdatalarısil') {
        handleTumDataSil(message);
    }
});

const handleMesaigir = (message) => {
    const userId = message.author.id;

    if (mesaiData[userId] && mesaiData[userId].some(mesai => mesai.end === null)) {
        message.reply('Zaten mesaiye girmiş durumdasınız.');
        return;
    }

    if (!mesaiData[userId]) {
        mesaiData[userId] = [];
    }

    mesaiData[userId].push({
        start: Date.now(),
        end: null
    });

    saveData();
    updateActivity(); // Aktiviteyi güncelle

    message.reply('Mesaiye başladınız.');
};

const handleMesaiCik = (message) => {
    const userId = message.author.id;

    if (!mesaiData[userId] || !mesaiData[userId].some(mesai => mesai.end === null)) {
        message.reply('Mesaiye başlamadınız ya da zaten mesaiyi bitirdiniz.');
        return;
    }

    const currentMesai = mesaiData[userId].find(mesai => mesai.end === null);
    currentMesai.end = Date.now();

    const duration = currentMesai.end - currentMesai.start;

    const seconds = Math.floor((duration / 1000) % 60);
    const minutes = Math.floor((duration / (1000 * 60)) % 60);
    const hours = Math.floor((duration / (1000 * 60 * 60)) % 24);

    saveData();
    updateActivity(); // Aktiviteyi güncelle

    message.reply(`Mesaiyi bitirdiniz. Bu mesai süresi: ${hours} saat, ${minutes} dakika, ${seconds} saniye.`);
};

const handleMesaibilgi = (message) => {
    const userId = message.author.id;

    if (!mesaiData[userId]) {
        message.reply('Mesaiye başlamadınız.');
        return;
    }

    const totalDuration = mesaiData[userId].reduce((total, mesai) => {
        if (mesai.end) {
            return total + (mesai.end - mesai.start);
        }
        return total;
    }, 0);

    const seconds = Math.floor((totalDuration / 1000) % 60);
    const minutes = Math.floor((totalDuration / (1000 * 60)) % 60);
    const hours = Math.floor((totalDuration / (1000 * 60 * 60)) % 24);

    message.reply(`Toplam mesai süreniz: ${hours} saat, ${minutes} dakika, ${seconds} saniye.`);
};

const handleAktif = (message) => {
    const activeUsers = Object.keys(mesaiData)
        .filter(userId => mesaiData[userId].some(mesai => mesai.end === null))
        .map(userId => `<@${userId}>`);

    if (activeUsers.length === 0) {
        message.reply('Şu anda aktif mesai yapan kimse yok.');
    } else {
        message.reply(`Şu anda aktif mesai yapanlar: ${activeUsers.join(', ')}`);
    }
};

const handleToplist = (message) => {
    const totalDurations = Object.keys(mesaiData).map(userId => {
        const totalDuration = mesaiData[userId].reduce((total, mesai) => {
            if (mesai.end) {
                return total + (mesai.end - mesai.start);
            }
            return total;
        }, 0);

        return { userId, totalDuration };
    });

    totalDurations.sort((a, b) => b.totalDuration - a.totalDuration);

    const toplist = totalDurations.map((user, index) => {
        const seconds = Math.floor((user.totalDuration / 1000) % 60);
        const minutes = Math.floor((user.totalDuration / (1000 * 60)) % 60);
        const hours = Math.floor((user.totalDuration / (1000 * 60 * 60)) % 24);

        return `${index + 1}. <@${user.userId}> - ${hours} saat, ${minutes} dakika, ${seconds} saniye`;
    }).join('\n');

    message.reply(`Mesai süreleri sıralaması:\n${toplist}`);
};

const handleMesaiCikar = (message) => {
    const mentionedUser = message.mentions.users.first(); // Etiketlenen kullanıcıyı al
    if (!mentionedUser) {
        message.reply('Çıkarılacak kullanıcıyı etiketlemeniz gerekiyor.'); // Etiketleme yapılmamışsa
        return;
    }

    const userId = mentionedUser.id;

    if (!mesaiData[userId] || !mesaiData[userId].some(mesai => mesai.end === null)) {
        message.reply('Etiketlediğiniz kullanıcının aktif mesaisi bulunmuyor.'); // Aktif mesai yoksa
        return;
    }

    // Aktif mesaiyi bul
    const currentMesaiIndex = mesaiData[userId].findIndex(mesai => mesai.end === null);
    if (currentMesaiIndex > -1) {
        // Aktif mesaiyi bitir
        mesaiData[userId].splice(currentMesaiIndex, 1); // Aktif mesaiyi veri tabanından çıkar
        saveData();
        updateActivity(); // Aktiviteyi güncelle

        message.reply(`<@${userId}> kullanıcısının aktif mesaisi çıkarıldı ve bu mesai süresi toplam süreye dahil edilmedi.`);
    } else {
        message.reply('Etiketlediğiniz kullanıcının aktif mesaisi bulunmuyor.');
    }
};

const handleMesaiLerisifirla = (message) => {
    for (const userId in mesaiData) {
        mesaiData[userId] = [];
    }

    saveData();
    updateActivity(); // Aktiviteyi güncelle

    message.reply('Tüm kullanıcıların mesai süreleri sıfırlandı.');
};

const handleMesaiSil = (message) => {
    const mentionedUser = message.mentions.users.first();
    if (!mentionedUser) {
        message.reply('Silinecek kullanıcıyı etiketlemeniz gerekiyor.');
        return;
    }

    const userId = mentionedUser.id;
    if (!mesaiData[userId]) {
        message.reply('Etiketlediğiniz kullanıcının mesai verisi bulunmuyor.');
        return;
    }

    delete mesaiData[userId];
    saveData();
    updateActivity(); // Aktiviteyi güncelle

    message.reply(`<@${userId}> kullanıcısının tüm mesai verileri silindi.`);
};

const handleTumDataSil = (message) => {
    mesaiData = {};
    saveData();
    updateActivity(); // Aktiviteyi güncelle

    message.reply('Tüm mesai verileri silindi.');
};

client.login(token);
